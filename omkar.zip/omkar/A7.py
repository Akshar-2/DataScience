import numpy as np
from sklearn.linear_model import LinearRegression

x = np.array([1,2,3,4,5,6,7,8]).reshape(-1,1)
y = np.array([7,14,15,18,19,21,26,23])

model = LinearRegression()
model.fit(x, y)

b1 = model.coef_[0]
b0 = model.intercept_
print(f"b0 (intercept): {b0}, b1 (coefficient): {b1}")
print("R2 Score:", model.score(x,y))