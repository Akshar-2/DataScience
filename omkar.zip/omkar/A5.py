
import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules


df = pd.read_csv('StudentsPerformance.csv')


df_cat = df[['gender',
             'race/ethnicity',
             'parental level of education',
             'lunch',
             'test preparation course']]


df_encoded = pd.get_dummies(df_cat)


frequent = apriori(
    df_encoded,
    min_support=0.5,
    use_colnames=True
)

rules = association_rules(
    frequent,
    metric="confidence",
    min_threshold=0.7
)

print("\nFrequent Itemsets:")
print(frequent)

print("\nAssociation Rules:")
print(rules)