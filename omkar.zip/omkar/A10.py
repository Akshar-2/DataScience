import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage

df = pd.read_csv('Wholesale customers data.csv')
X = df.iloc[:, 2:]

Z = linkage(X, method='ward')
dendrogram(Z)
plt.show()