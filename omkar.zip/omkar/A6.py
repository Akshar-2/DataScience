import pandas as pd

df = pd.read_csv('StudentsPerformance.csv')
print("Shape:", df.shape)
print(df.head())
print(df.sample(5)) 
print("Columns:", df.columns.tolist())
print("Num Columns:", df.shape[1])