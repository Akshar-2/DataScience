import pandas as pd
from sklearn.linear_model import LinearRegression

df = pd.read_csv('cars.csv') 
X = df[['Weight', 'Volume']]
y = df['CO2']

model = LinearRegression()
model.fit(X, y)
print(model.predict([[2300, 1300]])) 