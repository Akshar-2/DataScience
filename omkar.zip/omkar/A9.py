#Ass9
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

df = pd.read_csv('CC GENERAL.csv')
df.fillna(df.mean(numeric_only=True), inplace=True)
X = df.iloc[:, 1:]

sc = StandardScaler()
X_scaled = sc.fit_transform(X)

kmeans = KMeans(n_clusters=3)
df['Cluster'] = kmeans.fit_predict(X_scaled)
print(df.head(5))