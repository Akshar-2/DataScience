# ASS1
import pandas as pd

df = pd.read_csv('diabetes.csv')

print("Null values:\n", df.isnull().sum())
df_cleaned = df.dropna()

print("After removal shape:", df_cleaned.shape)
print(df_cleaned.head())