from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import GaussianNB

weather = ['Sunny','Sunny','Overcast','Rainy','Rainy','Rainy','Overcast','Sunny','Sunny','Rainy','Sunny','Overcast','Overcast','Rainy']
temp = ['Hot','Hot','Hot','Mild','Cool','Cool','Cool','Mild','Cool','Mild','Mild','Mild','Hot','Mild']
play = ['No','No','Yes','Yes','Yes','No','Yes','No','Yes','Yes','Yes','Yes','Yes','No']
le1 = LabelEncoder()
le2 = LabelEncoder()
le3 = LabelEncoder()
w_encoded = le1.fit_transform(weather) 
t_encoded = le2.fit_transform(temp) 
p_encoded = le3.fit_transform(play) 

features = list(zip(w_encoded, t_encoded))


model = GaussianNB()
model.fit(features, p_encoded)

result = model.predict([[0, 2]])
print(le3.inverse_transform(result)[0]) 